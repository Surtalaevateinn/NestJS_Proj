const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';

export const forestService = {
    async getForests(token: string) {
        const response = await fetch(`${API_BASE}/forests`, {
            headers: {
                'Authorization': `Bearer ${token}`,
            },
        });
        if (!response.ok) throw new Error('Failed to fetch forest data');
        return response.json(); // FeatureCollection
    }
};